@javax.xml.bind.annotation.XmlSchema(namespace = "http://hw2.pws/")
package pws.hw2;
